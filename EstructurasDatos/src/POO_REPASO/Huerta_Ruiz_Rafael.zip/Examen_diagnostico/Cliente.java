public class Cliente extends Persona{

    private String telefono;

    public Cliente(String nombre, int edad, String telefono) {
        super(nombre, edad);
        this.telefono = telefono;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono){
        this.telefono = telefono;
    }

    public void mostrar(){
        System.out.println("Nombre: " + this.getNombre());
        System.out.println("Edad: " + this.getEdad());
        System.out.println("Telefono: " + this.getTelefono());
    }

    public int calcularEdad(){
        int anio = 2022;
        int resuladoEdad = anio - this.getEdad();
        return resuladoEdad;
    }

}
